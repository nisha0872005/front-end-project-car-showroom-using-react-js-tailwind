import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-8">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Dealership Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">Nandu Motors</h3>
            <p className="text-gray-400">
              Driving excellence with premium vehicles, trusted service, and unmatched customer care.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="text-gray-400 space-y-2">
              <li className="hover:text-white transition"><Link to="/">Home</Link></li>
              <li className="hover:text-white transition"><Link to="/about">About Us</Link></li>
              <li className="hover:text-white transition"><Link to="/services">Services</Link></li>
              <li className="hover:text-white transition"><Link to="/inventory">Inventory</Link></li>
              <li className="hover:text-white transition"><Link to="/contact">Contact</Link></li>
            </ul>
          </div>

          {/* Contact & Social Media */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contact Us</h3>
            <p className="text-gray-400">📍 500 Auto Lane, DriveCity, IN 46204</p>
            <p className="text-gray-400">📞 +91 98765 43210</p>
            <p className="text-gray-400">📧 support@elitemotors.com</p>
            
            {/* Social Media Icons */}
            <div className="flex space-x-4 mt-4">
              <a href="#" className="hover:text-blue-500 transition">🔵 Facebook</a>
              <a href="#" className="hover:text-blue-400 transition">🐦 Twitter</a>
              <a href="#" className="hover:text-pink-400 transition">📸 Instagram</a>
              <a href="#" className="hover:text-red-500 transition">▶️ YouTube</a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-center text-gray-500 mt-8">
          <p>© 2025 Elite Motors. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
