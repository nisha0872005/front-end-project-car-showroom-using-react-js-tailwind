import React from "react";

const ServiceCard = ({ title, description, image }) => {
  return (
    <div className="bg-gradient-to-r from-indigo-800 to-blue-300 text-white rounded-2xl shadow-xl overflow-hidden transform transition-all hover:scale-105">
      <img className="w-full h-48 object-cover" src={image} alt={title} />
      <div className="p-4">
        <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
        <p className="text-gray-600 mt-2">{description}</p>
      </div>
    </div>
  );
};

const CarServicesSection = () => {
  const services = [
    {
      title: "Engine Diagnostics & Tuning",
      description: "Ensure optimal performance with advanced engine diagnostics and ECU tuning.",
      image: "https://th.bing.com/th/id/OIP.oNurvNIlsUQNI9MaIvEW1wHaE8?rs=1&pid=ImgDetMain",
    },
    {
      title: "Brake System Service",
      description: "From pad replacement to full system overhaul, we ensure your brakes are reliable and safe.",
      image: "https://4.bp.blogspot.com/-kXtNct1oaJ0/WssT5k2G3_I/AAAAAAAAAfw/mRUNYV3ty9AoGkasPKF48Gc2aAxLnqI2wCLcBGAs/s1600/brake%2Bservice3.jpg",
    },
    {
      title: "Oil Change & Filters",
      description: "Keep your engine running smoothly with regular oil changes and filter replacements.",
      image: "https://th.bing.com/th/id/OIP.fv5t-oO7wG1aMhwaEkcVVAHaE8?rs=1&pid=ImgDetMain",
    },
    {
      title: "Battery & Electrical Systems",
      description: "Get your battery, alternator, and entire electrical system tested and serviced.",
      image: "https://th.bing.com/th/id/OIP.huM5jvkwxVLwCIwc1PrWRgHaFj?rs=1&pid=ImgDetMain",
    },
    {
      title: "Suspension & Steering",
      description: "Smooth and safe handling starts with a properly tuned suspension and steering system.",
      image: "https://plymouth-auto.com/wp-content/uploads/2023/07/Plymoth-March-2023-Blog-cropped-A-shutterstock_2025066530.jpg",
    },
    {
      title: "Air Conditioning & Heating",
      description: "Stay comfortable year-round with our full HVAC diagnostics and repair services.",
      image: "https://img.blogs.es/circulaseguro/wp-content/uploads/2018/06/aire-acondicionado-2.jpg",
    },
    {
      title: "Transmission Repair",
      description: "We handle everything from fluid flushes to full transmission rebuilds with expert care.",
      image: "https://th.bing.com/th/id/OIP.1loEo9aeiMWGRy1DV3WowwHaFj?rs=1&pid=ImgDetMain",
    },
    {
      title: "Tire & Wheel Services",
      description: "Tire rotations, alignments, balancing, and more to keep your ride smooth and safe.",
      image: "https://jndautorepair.com/wp-content/uploads/2020/02/MAIN-TIRE-ROTATION.jpg",
    }
  ];

  return (
    <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 py-16 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-2">Our Automotive Services</h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Reliable solutions for every car part and system—professionally handled by our expert team.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard key={index} {...service} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default CarServicesSection;
