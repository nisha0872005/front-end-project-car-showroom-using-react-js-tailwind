const pricingPlans = [
    {
      title: "Basic Care",
      price: "₹1,999",
      features: [
        "Oil Change",
        "Tire Pressure Check",
        "Car Wash",
        "Fluid Top-up",
      ],
    },
    {
      title: "Premium Service",
      price: "₹4,999",
      highlight: true,
      features: [
        "Engine Diagnostics",
        "Brake Inspection",
        "Interior Vacuuming",
        "Exterior Polishing",
        "Free Pickup & Drop",
      ],
    },
    {
      title: "Elite Package",
      price: "₹9,999",
      features: [
        "Full Body Checkup",
        "AC & Cooling System Service",
        "Ceramic Coating",
        "Battery & Wiring Inspection",
        "Premium Support",
      ],
    },
  ];
  
  const Pricing = () => {
    return (
      <section
        className="py-16 text-white bg-cover bg-center relative"
        style={{
          backgroundImage:
            "url('https://img.freepik.com/premium-photo/artificial-intelligence-autonomous-car-concept_863013-50442.jpg')",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 opacity-90"></div>
  
        <div className="relative max-w-6xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-6">Car Service Pricing</h2>
          <p className="mb-12 text-gray-300">
            Choose the best plan that suits your vehicle’s needs and keep your ride smooth and stylish.
          </p>
  
          <div className="grid gap-8 md:grid-cols-3">
            {pricingPlans.map((plan, index) => (
              <div
                key={index}
                className={`rounded-xl p-8 shadow-2xl ${
                  plan.highlight
                    ? "bg-blue-600 border-2 border-blue-300"
                    : "bg-gray-800"
                }`}
              >
                <h3 className="text-2xl font-semibold mb-4">{plan.title}</h3>
                <p className="text-4xl font-bold mb-6">{plan.price}</p>
                <ul className="mb-6 space-y-2 text-gray-100">
                  {plan.features.map((feature, i) => (
                    <li key={i}>✅ {feature}</li>
                  ))}
                </ul>
                <button className="mt-4 px-6 py-2 bg-white text-gray-900 font-semibold rounded-lg hover:bg-gray-200 transition">
                  Book Now
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  };
  
  export default Pricing;
  