import React, { useState } from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-blue-950 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl font-bold">NANDU MOTORS</h1>
        <button
          className="block md:hidden text-white focus:outline-none"
          onClick={() => setIsOpen(!isOpen)}
        >
          ☰
        </button>

        <ul
          className={`md:flex md:space-x-6 absolute md:static top-16 left-0 w-full bg-blue-500 md:w-auto md:bg-transparent ${
            isOpen ? "block" : "hidden"
          }`}
        >
          <li className="p-2 hover:bg-blue-600 md:hover:bg-transparent">
            <Link to="/">Home</Link>
          </li>
          <li className="p-2 hover:bg-blue-600 md:hover:bg-transparent">
            <Link to="/about">About</Link>
          </li>
          <li className="p-2 hover:bg-blue-600 md:hover:bg-transparent">
            <Link to="/service">Services</Link>
          </li>
          <li className="p-2 hover:bg-blue-600 md:hover:bg-transparent">
            <Link to="/pricing">Pricing</Link>
          </li>
          <li className="p-2 hover:bg-blue-600 md:hover:bg-transparent">
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
