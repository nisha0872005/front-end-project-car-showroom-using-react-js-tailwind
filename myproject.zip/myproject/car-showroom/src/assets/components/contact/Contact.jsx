import React from "react";

const Contact = () => {
  return (
    <section className="py-16 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-4xl font-bold text-white">Contact Nandu Motors</h2>
        <p className="mt-4 text-gray-300">
          Interested in a vehicle, need car servicing, or want to book a test drive? We’re here to help!
        </p>
      </div>

      <div className="mt-10 max-w-4xl mx-auto bg-white p-8 shadow-2xl rounded-2xl">
        <form className="space-y-6">
          <div>
            <label className="block text-gray-700 font-semibold">Full Name</label>
            <input
              type="text"
              className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              placeholder="John Doe"
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold">Email Address</label>
            <input
              type="email"
              className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              placeholder="john@example.com"
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold">Phone Number</label>
            <input
              type="tel"
              className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              placeholder="+1 234 567 890"
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold">Service Type</label>
            <select className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600">
              <option>-- Select a Service --</option>
              <option>Test Drive</option>
              <option>Vehicle Inquiry</option>
              <option>Car Servicing</option>
              <option>Spare Parts Request</option>
              <option>Finance & Insurance</option>
            </select>
          </div>
          <div>
            <label className="block text-gray-700 font-semibold">Message</label>
            <textarea
              rows="4"
              className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              placeholder="Let us know what you're looking for, and we'll get back to you ASAP."
            ></textarea>
          </div>
          <button
            type="submit"
            className="w-full p-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition"
          >
            Send Request
          </button>
        </form>
      </div>
    </section>
  );
};

export default Contact;
