import React from "react";

const AboutSection = () => {
  return (
    <div className="bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#0f172a] py-12">
      <div className="container mx-auto p-6 space-y-10">
        {/* Main About Section */}
        <div className="bg-gradient-to-br from-blue-200 via-blue-500 to-blue-200 text-white rounded-2xl shadow-2xl p-8 text-center">

          <div className="flex flex-col md:flex-row items-center">
            {/* Image Section */}
            <div className="md:w-1/2">
              <img 
                src="https://i.pinimg.com/736x/3e/b6/d4/3eb6d4b9dbd44451526a7773de5104f3.jpg"
                alt="Car Showroom Interior" 
                className="rounded-lg shadow-md w-full h-auto object-cover"
              />
            </div>

            {/* Text Content */}
            <div className="md:w-1/2 mt-6 md:mt-0 md:ml-8 text-center md:text-left">
              <h2 className="text-3xl font-bold mb-4 text-gray-900">About Nandu Motors</h2>
              <p className="text-lg text-gray-700 mb-4">
                At <strong>Nandu Motors</strong>, we specialize in connecting drivers with their dream cars. From high-performance sports models to executive luxury vehicles, our curated selection is unmatched.
              </p>
              <p className="text-lg text-gray-700 mb-4">
                Our showroom is designed to offer a premium, personalized experience. Explore the latest models, cutting-edge features, and world-class customer service — all in one place.
              </p>
              <p className="text-lg text-gray-700 mb-4">
                With over <strong>15 years of experience</strong> in the automotive industry, we’ve earned a reputation for trust, integrity, and exceptional care. Whether you’re buying, trading, or just exploring, we’re here to guide you every step of the way.
              </p>
              <p className="text-lg text-gray-700 mb-4">
                Visit us today and let our passionate team help you experience driving like never before.
              </p>
              <button className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                View Inventory
              </button>
            </div>
          </div>
        </div>

        {/* Additional Card */}
        <div className="bg-gradient-to-br from-blue-500 via-blue-500 to-blue-200 text-white rounded-2xl shadow-2xl p-8 text-center
">
          <h3 className="text-2xl font-semibold mb-4">Why Choose Nandu Motors?</h3>
          <p className="text-gray-700 text-lg mb-2">
            ✓ Handpicked premium cars from trusted brands
          </p>
          <p className="text-gray-700 text-lg mb-2">
            ✓ Transparent pricing with no hidden fees
          </p>
          <p className="text-gray-700 text-lg mb-2">
            ✓ Dedicated post-sale service & maintenance support
          </p>
          <p className="text-gray-700 text-lg">
            ✓ Financing options tailored to your needs
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutSection;
