
import './App.css'
import Navbar from './assets/components/navbar/Nav'
import Hero from './assets/components/hero/Hero'
import Contact from './assets/components/contact/Contact'
import About from './assets/components/about/About'
import Service from './assets/components/service/Service'
import Footer from './assets/components/footer/Footer'
import Pricing from './assets/components/pricing/Pricing'

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
function App() {
  

  return (
    <>
     <Router>
      <Navbar/>
    
      
      <Routes>
        <Route path="/" element={<Hero />} />
        <Route path="/Home" element={<Hero />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/service" element={<Service />} />
        <Route path="/pricing" element={<Pricing />} />
        
      </Routes>
      
      <Footer/>
      </Router>
      
       
    </>
  )
}

export default App
